/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BloodBankManagement;
import java.awt.Image;
import java.util.*;
/**
 *
 * @author johncalkins
 */
public class Blood {
    private String type;
    private Donor donator;
    private Calendar given; 
    private Calendar expires;
    private Image image;
    private String notes;
    public Blood(String tp, Donor don, int monthGiven, int dayGiven, int yearGiven, Image i, String n)
    {
        type = tp;
        given.set(yearGiven, monthGiven, dayGiven);
        expires.set(yearGiven, monthGiven, dayGiven);
        expires.add(dayGiven,46);
        donator = don;
        image = i;
        notes = n;
    }
}
