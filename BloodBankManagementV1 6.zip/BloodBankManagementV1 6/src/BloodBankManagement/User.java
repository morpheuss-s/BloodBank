/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BloodBankManagement;

/**
 *
 * @author johncalkins
 */
public class User {
    private String userName;
    private String password;
    private boolean admin;
    private boolean restricted;
    
    public User(String nme, String pw, boolean adm, boolean rst)
    {
        userName = nme;
        password = pw;
        admin = adm;
        restricted = rst;
    }
    
}
